Notes:
1, There are two warnings caused by using the exact method signatures provided without adding a type for the ArrayList.
2, It was not stated that the order of the path method output mattered. It was assumed that it didn't.
3, There are tests within this zip.
4, Comments were avoiding in order to save time. I would normally add comments and can explain my code in detail.